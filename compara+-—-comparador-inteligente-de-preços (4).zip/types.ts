
export interface MarketplaceOption {
  productName: string;
  store: string;
  price: number;
  shipping: number;
  finalPrice: number;
  evaluation: string;
  sellerReputation: string;
  link: string;
  imageUrl?: string;
}

export interface SearchResult {
  bestOption: MarketplaceOption;
  others: MarketplaceOption[];
}

export enum AppStatus {
  IDLE = 'IDLE',
  SEARCHING = 'SEARCHING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
  NOT_FOUND = 'NOT_FOUND'
}

export enum Tab {
  HOME = 'HOME',
  PRICES = 'PRICES',
  FAVORITES = 'FAVORITES',
  STORES = 'STORES'
}
