
import React from 'react';
import { MarketplaceOption } from '../types';

interface ProductCardProps {
  option: MarketplaceOption;
  isBest?: boolean;
  onClick?: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ option, isBest = false, onClick }) => {
  const formatCurrency = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const getStoreLogo = (store: string) => {
    const storeLower = store.toLowerCase();
    if (storeLower.includes('shopee')) return <span className="text-orange-600 font-black">S</span>;
    if (storeLower.includes('mercado')) return <span className="text-yellow-500 font-black">M</span>;
    if (storeLower.includes('amazon')) return <span className="text-black font-black">a</span>;
    if (storeLower.includes('magalu')) return <span className="text-blue-500 font-black">M</span>;
    return <span className="text-blue-600 font-black">{store.substring(0, 1)}</span>;
  };

  return (
    <div 
      onClick={onClick}
      className={`bg-white p-5 mb-1 border-b border-gray-100 last:border-0 hover:bg-gray-50 transition-colors flex items-center justify-between cursor-pointer group`}
    >
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 flex items-center justify-center rounded-2xl border border-gray-100 bg-white overflow-hidden p-1 shadow-sm group-hover:scale-105 transition-transform">
           {option.imageUrl ? (
             <img src={option.imageUrl} alt={option.store} className="w-full h-full object-contain" />
           ) : getStoreLogo(option.store)}
        </div>
        <div>
          <h4 className="text-gray-900 font-black text-sm leading-none mb-1">{option.store}</h4>
          {option.shipping === 0 ? (
            <div className="bg-emerald-50 px-2 py-0.5 rounded-md inline-block">
              <span className="text-emerald-600 text-[9px] font-black uppercase tracking-tight">Frete Grátis</span>
            </div>
          ) : (
            <span className="text-gray-400 text-[10px] mt-0.5 block font-bold">+ {formatCurrency(option.shipping)} frete</span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="text-right">
          <span className="text-gray-900 font-black text-sm">{formatCurrency(option.finalPrice)}</span>
          {isBest && (
            <div className="text-[8px] font-black text-emerald-500 leading-none mt-1 animate-pulse">MELHOR PREÇO</div>
          )}
        </div>
        <a 
          href={option.link}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="bg-[#1e4eb8] text-white p-2.5 rounded-xl hover:bg-blue-700 transition-colors shadow-md"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" />
          </svg>
        </a>
      </div>
    </div>
  );
};

export default ProductCard;
