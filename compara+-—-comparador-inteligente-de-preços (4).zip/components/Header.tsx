
import React from 'react';

interface HeaderProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
}

const Header: React.FC<HeaderProps> = ({ onSearch, isLoading }) => {
  const [inputValue, setInputValue] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onSearch(inputValue);
    }
  };

  return (
    <div className="bg-[#1e4eb8] pb-8 pt-6 px-6 rounded-b-[40px] shadow-2xl relative z-10 border-b border-white/10">
      <div className="max-w-md mx-auto">
        {/* Professional Logo Bar */}
        <div className="flex justify-between items-center mb-5 relative">
          {/* Spacer to maintain center alignment of logo */}
          <div className="w-8"></div>
          
          {/* Main Logo Group */}
          <div className="flex items-center gap-2.5 group">
            <div className="text-white">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2.5" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-7 h-7"
              >
                <circle cx="9" cy="21" r="1" />
                <circle cx="20" cy="21" r="1" />
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
              </svg>
            </div>
            <h1 className="text-white text-2xl font-black tracking-tighter leading-none">
              Compara+
            </h1>
          </div>

          {/* Minimalist Search Toggle Button */}
          <button className="text-white/80 hover:text-white active:scale-90 transition-all p-1.5 rounded-full hover:bg-white/10">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35" />
            </svg>
          </button>
        </div>

        {/* Brand Slogan */}
        <div className="text-center mb-7">
          <p className="text-white/80 text-xs font-semibold uppercase tracking-widest">Compare preços e economize.</p>
        </div>

        {/* Premium Search Input */}
        <form onSubmit={handleSubmit} className="relative mb-7">
          <div className="relative group">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none transition-colors group-focus-within:text-[#1e4eb8]">
              <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Buscar produto..."
              className="w-full bg-white text-gray-800 pl-12 pr-6 py-4 rounded-2xl shadow-xl focus:outline-none text-sm font-semibold transition-all focus:ring-2 focus:ring-white/20"
              disabled={isLoading}
            />
          </div>
        </form>

        {/* Action Buttons Grid (Style from reference image) */}
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <button className="bg-[#f28e2b] text-white px-4 py-3.5 rounded-xl text-[11px] font-bold flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 012.495-2.25 2.64 2.64 0 012.64 2.64c0 1.458-1.182 2.64-2.64 2.64a2.64 2.64 0 01-2.64-2.64c0-.285.045-.558.128-.814a33.32 33.32 0 01-.128-4.48c.18-1.077.447-2.126.837-3.067a12.86 12.86 0 011.082-2.115c.346-.494.85-.98 1.547-1.185A1 1 0 0012.395 2.553z" clipRule="evenodd" /><path d="M4.418 13.918l-.946.946a4 4 0 005.657 5.657l.946-.946a4 4 0 10-5.657-5.657z" /></svg>
              Ofertas do Dia
            </button>
            <button className="bg-[#3e76c1] text-white px-4 py-3.5 rounded-xl text-[11px] font-bold flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
              Mais Buscados
            </button>
          </div>
          <button className="w-full bg-[#45968c] text-white px-4 py-3.5 rounded-xl text-[11px] font-bold flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5"><path strokeLinecap="round" strokeLinejoin="round" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" /></svg>
            Cupons
          </button>
        </div>
      </div>
    </div>
  );
};

export default Header;
