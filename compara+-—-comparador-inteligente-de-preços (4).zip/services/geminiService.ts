
import { GoogleGenAI, Type } from "@google/genai";
import { SearchResult, MarketplaceOption } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
Você é o COMPARA+, o comparador de preços mais preciso do Brasil.
Sua missão: Encontrar o MENOR preço final para o usuário, considerando Preço + Frete.

Diretrizes de Busca:
1. Use o Google Search para encontrar preços AO VIVO em: Amazon.com.br, Mercado Livre, Shopee, Magalu, Kabum e Casas Bahia.
2. Priorize produtos em estoque e com links diretos de compra.
3. Se houver cupons conhecidos ou promoções "Prime/Fidelidade", mencione se possível no preço.
4. Extraia URLs de imagens reais dos produtos.
5. O campo "link" deve ser a URL direta para a página do produto na loja.
6. Se não encontrar o produto exato, busque a versão mais próxima disponível.

Formato de Saída: JSON rigoroso.
`;

export const searchProduct = async (query: string): Promise<SearchResult | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Compare agora o preço de: "${query}". Retorne as 5 melhores opções encontradas em lojas brasileiras confiáveis.`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            bestOption: {
              type: Type.OBJECT,
              properties: {
                productName: { type: Type.STRING },
                store: { type: Type.STRING },
                price: { type: Type.NUMBER },
                shipping: { type: Type.NUMBER },
                finalPrice: { type: Type.NUMBER },
                evaluation: { type: Type.STRING },
                sellerReputation: { type: Type.STRING },
                link: { type: Type.STRING },
                imageUrl: { type: Type.STRING }
              },
              required: ["productName", "store", "price", "shipping", "finalPrice", "link"]
            },
            others: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  productName: { type: Type.STRING },
                  store: { type: Type.STRING },
                  price: { type: Type.NUMBER },
                  shipping: { type: Type.NUMBER },
                  finalPrice: { type: Type.NUMBER },
                  evaluation: { type: Type.STRING },
                  sellerReputation: { type: Type.STRING },
                  link: { type: Type.STRING },
                  imageUrl: { type: Type.STRING }
                },
                required: ["productName", "store", "price", "shipping", "finalPrice", "link"]
              }
            }
          },
          required: ["bestOption", "others"]
        }
      }
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as SearchResult;
  } catch (error) {
    console.error("Erro na busca inteligente:", error);
    return null;
  }
};
